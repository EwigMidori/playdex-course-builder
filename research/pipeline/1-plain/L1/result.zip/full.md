# L1: Algorithmic trading basics and financial markets

Course Code: COMP7415

# Agenda

- The basic concept of algo-trading   
- The market trend of algo-trading   
- Comparison of different trading approaches   
• Infrastructure needed to deploy algo-trading programs   
- Trading mechanism and order matching   
Market jargon and terminology

# What is algo-trading?

- Algorithmic trading, also called Algo Trading, Quant Trading, Robo-Trading, Program Trading   
- Use of mathematical models and computer algorithms/programs to

- generate trading signals (i.e. Decision making)   
- automate trading process (i.e. Execution)

- Objectives:

- maximize profits   
- control execution costs   
- hedging and manage investment risks

# Market Trend for Algo-Trading

Expected to grow at CAGR $12.7\%$ to US $\$ 32$ b by 2028   
- Largest market in North America   
- Fastest growing in Asia Pacific

![](images/23944073ff63d8284dc99146e03872d7534460656b988edca49867c2a1823382.jpg)

![](images/553c1850eb62275b06eb4b2fa2de02aa49eb0882c33893ea01dbf6746a04d526.jpg)

# Market Trend for Algo-Trading

Algorithmic trading strategies account for approximately:

60% of all US equity volume   
40% of all European equity volume   
25% of all Forex transactions   
20% of all US option trades

# Robo-Trading vs Robo-Advisory

<table><tr><td></td><td>Robo-Trading</td><td>Robo-Advisory</td></tr><tr><td>Decision making</td><td>✓</td><td>✓</td></tr><tr><td>Execution</td><td>✓</td><td>×</td></tr><tr><td>Automation</td><td>Fully automated</td><td>Semi-automated</td></tr><tr><td>Outputs</td><td>Execution of trading signals</td><td>• Stock advices
• Market summary
• Risk alerts</td></tr></table>

![](images/2853c1739330c29f9f1c777cb0195998cf6f596c913e4ccd557e9da5aa1bb6d5.jpg)

ALGOGENE

FinTech Co. Ltd.

JOIN US ON TELEGRAM

ALGOGENESIGNAL

FREE DAILY REAL-TIME TRADING SIGNALS

![](images/de6188289d2654bafc1a1dc3b641da604e09b47ea7d604dbc7620e6c670f49e3.jpg)  
@algogene_signal

![](images/fd8bf798e299893a5e056c49cb7b184a1a3217af05382e16f6f2651b4fb021eb.jpg)  
Warning: Beware of scam Telegram groups. Please note that the only official group is @algogene_signal

# Comparison of Trading Approaches

manual

automatic

<table><tr><td></td><td>Human Trading</td><td>Robo-Advisory</td><td>Robo-Trading</td></tr><tr><td>Working Hours</td><td>~9*5</td><td>~9*5</td><td>24*7</td></tr><tr><td>Execution Speed</td><td>Slow</td><td>Moderate</td><td>Immediately</td></tr><tr><td>Data Inputs</td><td>Limited</td><td>Almost unlimited</td><td>Almost unlimited</td></tr><tr><td>Trading Frequency</td><td>Low</td><td>Low - mid</td><td>Low – High</td></tr><tr><td>Scalability</td><td>Limited investment size due to stress</td><td>Moderate</td><td>High</td></tr><tr><td>Accuracy/ Discipline</td><td>Variable especially when you lose</td><td>Consistent</td><td>High</td></tr><tr><td>Customization</td><td>High</td><td>Medium</td><td>Low</td></tr><tr><td>User Control</td><td>Full</td><td>Partial</td><td>Minimal</td></tr><tr><td>Risk Management</td><td>Subjective</td><td>Algorithmsic</td><td>Algorithmsic</td></tr></table>

# What should you consider to implement a trading algo?

# Algo is the vehicle; Data is the Fuel!

- Data collection - time and effort demanding in data sourcing and data cleaning   
- Data storage - high volume of unstructured data (Numeric, Text, Image, Audio, Video)   
- Data management - difficult to protect and manage through traditional databases due to inconsistent file and data formats   
- Data processing - feasibility and efficiency

# Other factors for infrastructure setup

Real-time datafeed   
Historical data   
- Computing hardware   
- Exchange/broker connectivity   
Network and latencies   
- Order routing system   
- Order management system   
- Algo maintenance   
- Cybersecurity   
•

# General Trading Overview

# Types of Trading

# Fundamental:

Stock Selection   
Ratio Analysis   
Sector Analysis   
- Corporate and Executive Management

# Technical:

Chart pattern   
Trend Analysis

# Quantitative:

- Rule based   
Econometric Forecasting   
- Statistical Arbitrage   
- NLP, sentiment analysis   
Machine learning

# Types of Trading

# Time Frames:

- Long Term: Months to Years   
- Short Term: Days, Weeks, Months   
- Intraday: Seconds to Hours   
High frequency: Fractions of Seconds

# How trading works?

# Supply

# Current Stock holders

(each person holds 1 share)

![](images/e1e057b7d7fc7bd49d1922c8618de93b1532198a870066b4b588c4a6e747b863.jpg)

\$10

![](images/66e3829fdc2f9a0f1edca0c5ace158988518b86d015f6fc75ee5cefefccb670e.jpg)

\$12

![](images/d921225e2a9e350d3724bb19428a5369a223a20629e8267e8315f29e57225ff8.jpg)

\$13

![](images/a7cd152fad3ea773dfc34758a660b3b44bde991f91098ff56886415994b2c5b0.jpg)

\$15

![](images/2c15a222210bda5e996f2d424cdd93045f1743e4fc8d2e373a46b1d91ec36d2f.jpg)

\$15

![](images/07b0516b07de265bd3af8149f935a07966e05b6833e24644b9ba5380bb31193d.jpg)

§18

![](images/ea229043a908c9e6318d587100f327366a95cbfd88d28e42875c259efb8e7488.jpg)

\$21

![](images/b7433937afe87c2c5138a2b99115896ca2d0be9178a7865367cd1018684896b5.jpg)

\$24

![](images/c662c065d1d2f712b08d36d87935a02918fcc93834c64e0e658d884bb5a52cea.jpg)

\$25

![](images/675692737d29622eb03acbdd2b2a9b309f08b211b547e8d38cd23dc6a6c7c1df.jpg)

\$30

Price they would be willing to take (sell) for their shares

# Current Stock holders

(each person holds 1 share)

![](images/52ec0b281f70a1907f11cd9bcdbe75ca3025f7a016e47f91919ca77cb9916500.jpg)  
\$10

![](images/ec193921ae31a6a1b9329a744b1f29dd670608eb6067868e0a39832cf90f7fb5.jpg)  
\$12

![](images/8e3bef9a43fbaa662ef8c08f251003ed266561e796f09187c02db0e9c203e841.jpg)  
\$13

![](images/06f7364de3af917c64e52c55f661a3cfadb3e337c7d459b97f3adfd4561d292a.jpg)  
§15

![](images/c4e433c1285445be0abd10d4c5d990e18a91d14a48e16132abde1da0b7995355.jpg)  
\$15

![](images/b159aa9cfb0666b2024460c1f36e18619269c8906996bb51020078ad49d3f411.jpg)  
\$18

![](images/7d9ab41481da4def300804b68f53a9667de9caa3a135f6b4e76d99ae94b44919.jpg)  
§21

![](images/50b5782f452ccf7179c6361e3c335625a79aef32126ff58efd75da45c7863c35.jpg)  
\$24

![](images/17d0f1edeb826aea3aba36a5da72f534551146c03935ce571aaecb1f7338bf1d.jpg)  
\$25

![](images/7260e8fa9b83862c1abdc122adc83b69727c390d3221246163add8669ed38725.jpg)  
\$30

![](images/bf1c4e7961e05025587eeee299249a966b057686a903f3cf5b4099aaa6044ca1.jpg)  
Supply

<table><tr><td>Price</td><td>Supply</td></tr><tr><td>1</td><td>0</td></tr><tr><td>2</td><td>0</td></tr><tr><td>3</td><td>0</td></tr><tr><td>4</td><td>0</td></tr><tr><td>5</td><td>0</td></tr><tr><td>6</td><td>0</td></tr><tr><td>7</td><td>0</td></tr><tr><td>8</td><td>0</td></tr><tr><td>9</td><td>0</td></tr><tr><td>10</td><td>1</td></tr><tr><td>11</td><td>1</td></tr><tr><td>12</td><td>2</td></tr><tr><td>13</td><td>3</td></tr><tr><td>14</td><td>3</td></tr><tr><td>15</td><td>5</td></tr><tr><td>16</td><td>5</td></tr><tr><td>17</td><td>5</td></tr><tr><td>18</td><td>6</td></tr><tr><td>19</td><td>6</td></tr><tr><td>20</td><td>6</td></tr><tr><td>21</td><td>7</td></tr><tr><td>22</td><td>7</td></tr><tr><td>23</td><td>7</td></tr><tr><td>24</td><td>8</td></tr><tr><td>25</td><td>9</td></tr><tr><td>26</td><td>9</td></tr><tr><td>27</td><td>9</td></tr><tr><td>28</td><td>9</td></tr><tr><td>29</td><td>9</td></tr><tr><td>30</td><td>10</td></tr></table>

# Demand

# Potential Buyers

(each person wants to buy 1 share)

![](images/86360fdbfc0686ed5bb93811e5120194b63bed941a41f8ac4a700fd590f386d1.jpg)  
\$5

![](images/ff7d024e6fdbd516099aac633e061ba672cdb00e0cd864ed2a471baed275ac24.jpg)  
\$6

![](images/8f6548cbaa3e1b713e127969356e4339b881c4ee8275b8ebd5df0f79b84d7d54.jpg)  
\$8

![](images/580ed35fd6987c7196b168c9cd67feef87601c8798035b2fff33f45015c54af9.jpg)  
\$10

![](images/19c846959eada8c2a10d9b73544e81da601822ef1beaf3f4e93cfa8c3442ba1b.jpg)  
\$11

![](images/d4b978d4f62c3ceea2332c78ae9860aa33aba5e20368417b05810fb4adb5151c.jpg)  
\$12

![](images/d71b1972d6855ba25b49c3b78bb4e1e22d291978b507f04ffa2aa07400e63ef3.jpg)  
\$14

![](images/9af52572b328901eb34ae9e7dae44f14ea5f3adf7dc096877753435b7beea51a.jpg)  
\$15

Price they would be willing to pay for a share

# Potential Buyers

(each person wants to buy 1 share)

![](images/f9845d43e9a67e8bec11c308e4298e306417b8a1b810c67728463ac833f964c2.jpg)  
\$5

![](images/ea06648c52b2b8248ac449299981beabbdc442eaaf32e3f3c8b35f518283f3b3.jpg)  
\$6

![](images/1d3da68bc93fbd3118d914887ba9d65239dafab534b282ec9a303731544ba453.jpg)  
\$8

![](images/a34cb16fa73a9c47eee81913a1885913af2c50f5ad68f9d31880b4a5007bb092.jpg)  
\$10

![](images/53e2929550688514b55498c072399e99ea74d36063d4f814f662f5d7acc989e9.jpg)  
\$11

![](images/53367305a6e49e7db8201b8a03c85905647a0a1a65296357168ba45f6a1c20d0.jpg)  
\$12

![](images/97430e1e313c1f795221b38b9e4afcf8ecba246b88da7c62fe2966284a65f550.jpg)  
\$14

![](images/0fd2f01994766eed041dfda9e2cf6227c79bcf109d7c5885a8fd005b39f9fa4a.jpg)  
\$15

![](images/798449f0918ee7b311b24223b49c1897c83f94b9c422e3a97ca3de9563e95aec.jpg)  
Demand

<table><tr><td>Price</td><td>Demand</td></tr><tr><td>1</td><td>8</td></tr><tr><td>2</td><td>8</td></tr><tr><td>3</td><td>8</td></tr><tr><td>4</td><td>8</td></tr><tr><td>5</td><td>8</td></tr><tr><td>6</td><td>7</td></tr><tr><td>7</td><td>6</td></tr><tr><td>8</td><td>6</td></tr><tr><td>9</td><td>5</td></tr><tr><td>10</td><td>5</td></tr><tr><td>11</td><td>4</td></tr><tr><td>12</td><td>3</td></tr><tr><td>13</td><td>2</td></tr><tr><td>14</td><td>2</td></tr><tr><td>15</td><td>1</td></tr><tr><td>16</td><td>0</td></tr><tr><td>17</td><td>0</td></tr><tr><td>18</td><td>0</td></tr><tr><td>19</td><td>0</td></tr><tr><td>20</td><td>0</td></tr><tr><td>21</td><td>0</td></tr><tr><td>22</td><td>0</td></tr><tr><td>23</td><td>0</td></tr><tr><td>24</td><td>0</td></tr><tr><td>25</td><td>0</td></tr><tr><td>26</td><td>0</td></tr><tr><td>27</td><td>0</td></tr><tr><td>28</td><td>0</td></tr><tr><td>29</td><td>0</td></tr><tr><td>30</td><td>0</td></tr></table>

# Market Equilibrium

![](images/3627bc4390ce1dee9b9bd69fe4614da45984046abf62f9f1d460331c494cda71.jpg)  
- The market is balanced at \(12 and quantity 2

<table><tr><td>Price</td><td>Supply</td><td>Demand</td></tr><tr><td>1</td><td>0</td><td>8</td></tr><tr><td>2</td><td>0</td><td>8</td></tr><tr><td>3</td><td>0</td><td>8</td></tr><tr><td>4</td><td>0</td><td>8</td></tr><tr><td>5</td><td>0</td><td>8</td></tr><tr><td>6</td><td>0</td><td>7</td></tr><tr><td>7</td><td>0</td><td>6</td></tr><tr><td>8</td><td>0</td><td>6</td></tr><tr><td>9</td><td>0</td><td>5</td></tr><tr><td>10</td><td>1</td><td>5</td></tr><tr><td>11</td><td>1</td><td>4</td></tr><tr><td>12</td><td>2</td><td>3</td></tr><tr><td>13</td><td>3</td><td>2</td></tr><tr><td>14</td><td>3</td><td>2</td></tr><tr><td>15</td><td>5</td><td>1</td></tr><tr><td>16</td><td>5</td><td>0</td></tr><tr><td>17</td><td>5</td><td>0</td></tr><tr><td>18</td><td>6</td><td>0</td></tr><tr><td>19</td><td>6</td><td>0</td></tr><tr><td>20</td><td>6</td><td>0</td></tr><tr><td>21</td><td>7</td><td>0</td></tr><tr><td>22</td><td>7</td><td>0</td></tr><tr><td>23</td><td>7</td><td>0</td></tr><tr><td>24</td><td>8</td><td>0</td></tr><tr><td>25</td><td>9</td><td>0</td></tr><tr><td>26</td><td>9</td><td>0</td></tr><tr><td>27</td><td>9</td><td>0</td></tr><tr><td>28</td><td>9</td><td>0</td></tr><tr><td>29</td><td>9</td><td>0</td></tr><tr><td>30</td><td>10</td><td>0</td></tr></table>

# Order Matching

Current Stock holders

(each person holds 1 share)

![](images/76aa0950e4bed1acbae25a888f81f80f26e02ad4816ac50a4e5f2cda985a5a5c.jpg)  
\$10

![](images/1f357fd8c08721af06955e9d33adc38fd16d170af4534feb93ce922e9a425408.jpg)  
\$12

![](images/aea51de4de548ab864441c2f29f0929981552e505b19d8ca6f4387c9f610acc1.jpg)  
§13

![](images/49348a9f5482cff7509c96a4fae1a772326c9ab3afb5cb7a34308253ac4cc658.jpg)  
§15

![](images/851355a500a0f68a90ef3b5fad5900aca59944d9ea7b0951a7792cf1b569dda7.jpg)  
§15

![](images/3445f9a5d095f145645fe50b2af3810421817e28764d4c9f7e7a54fe02081038.jpg)  
\$18

![](images/edcd72bb496047cbb6319d697cbba23add728497dbe45be16de454c989d1b0a4.jpg)  
\$21

![](images/9c68fd8438dd884e2c4ab5d05ac10dd293f58d9b48c4eb96653921cf7114779b.jpg)  
\$24

![](images/c7b40ea70ccfd7c190613148a573cf062a3deae264c2d94bad90f3cd4c9a5344.jpg)  
\$25

![](images/6b6e4930be7a80fb5a92ec4019c83a4c51fe0310ef43f1074b8d16f04cbdff16.jpg)  
\$30

![](images/cbe70f1303278c4c79c22ed1f4ac31d586403e249a224b69dc39cf5770967f5f.jpg)  
\$5

![](images/8fd2a487e6a8152df82085f0e3bdae08bc244fdcee14e5d2a5f550a64b6580e4.jpg)  
\$6

![](images/164a700d165ac8c5b3f94eaea21ab59192e6f33d7ea0fa8f7392d76677e0f7b2.jpg)  
\$8

![](images/b07aaf00beb0d6cfc09d252c8f5a194755afe07e36f4939a5978924f6ea79fcc.jpg)  
\$10

![](images/025b679b5a14eadbc8880a50ca03f9ec5fe7460893eb7117942104fd9f7a8bba.jpg)  
\$11

![](images/2e019b398a59c07427da55d6ecd1cb7ea0de78f944c07bb2ea88de882b9cb3a0.jpg)  
\$12

![](images/e9ab0a6e59e18c44ec1f59ebfae68ba97e95c620319bd66523ea6b5bbad78f3f.jpg)  
\$14

![](images/8eb4771a0565203e595ebee6ff63810e8632a21620fcbdf627b1737938c749c7.jpg)  
\$15   
Potential Buyers   
(each person wants to buy 1 share)

# After Order Matching

![](images/2340feec59164504691d63240722a35cea786eabff0e8034687ee80be2a41dd4.jpg)

# Market Terminology

# Common market terminology

1. Long and short position   
2. Short-selling   
3. Order book   
4. Bid price, ask price   
5. Market spread   
6. Order types   
7. Slippage   
8. Mark-to-market   
9. Trading system   
10. Margin & leverage

# Understanding Long and Short Positions

- Long Position

• Definition: Buying an asset with the expectation that its price will rise.   
- Goal: Sell at a higher price to realize a profit.   
• Example: Buying 100 shares of a stock at $50, selling when it reaches$ 70.

![](images/e4a7b63262ab10be6402b5b91c04159ccb3f664d558c127eadc3d9b8df361959.jpg)  
Long

# Understanding Long and Short Positions

# - Short Position

- Definition: Selling an asset that you do not own, with the intention of buying it back later at a lower price.   
- Goal: Profit from a decline in the asset's price.   
• Example: Selling 100 shares of a stock at $70, buying back at$ 50.

![](images/46c2fd97f0af2633c54158e3594122c54c05f9f8c58c405f4d569dce6c33c804.jpg)

# How Short-Selling Works

1. Borrowing Shares: Obtain shares from a broker to sell.   
2. Selling the Borrowed Shares: Sell the shares at the current market price.   
3. Buying Back Shares: Later, buy the same number of shares at a lower price.   
4. Returning Shares: Return the borrowed shares to the broker.

![](images/f91be6e8633dfd9caaf37fd019f26e0d75c126588d6adc96dc5b9c3e030fc177.jpg)

# Risks of Short-Selling

- Unlimited Loss Potential: If the asset price rises significantly.   
- Margin Calls: Brokers may require additional funds if the trade goes against you.   
- Regulatory Risks: Short-selling can be subject to restrictions.

![](images/f0e8373ee69422c3e7de92d9b404515e2bbc07233ecf3a9f25b69838993184ec.jpg)

# Order Book

- The Order Book is a real-time, continually updating list of buy and sell orders for a specific financial instrument, sorted by price level.   
Key components

- Ask Book: the list/queue for sellers   
- Bid Book: the list/queue for buyers   
- Price: The price points at which investors are willing to trade   
Size: The number of shares, contracts, or lots that traders want to buy or sell

# How does Order Book present?

1. Order Ledger   
2. Top of the Book   
3. Cumulative Book

# Order Ledger

- The order book is listed in a sorted price ledger, which can be ascending or descending.   
- The longer the price ledger is, the more liquidity an instrument provides. It is also called "market depth".

![](images/1c4327d010822d6548850f694f7c27fde9fc3a6d0c9c3008732a3d8ee04a4aad.jpg)

# Top of the Book

- The order book is separated into bid-book and ask-book   
- Bid orders are sorted in descending price   
- Ask orders are sorted in ascending price   
- The highest bid and the lowest ask are referred to "the top of the book"

Order Book

<table><tr><td></td><td>Bid</td><td>Ask</td><td></td></tr><tr><td>3,151</td><td>9139.60</td><td>9152.80</td><td>167</td></tr><tr><td>1,574</td><td>9138.40</td><td>9153.21</td><td>1,600</td></tr><tr><td>338</td><td>9138.20</td><td>9153.60</td><td>736</td></tr><tr><td>789</td><td>9138.10</td><td>9153.71</td><td>1,602</td></tr><tr><td>800</td><td>9138.00</td><td>9154.10</td><td>1,649</td></tr><tr><td>309</td><td>9137.79</td><td>9154.21</td><td>1,965</td></tr><tr><td>2,140</td><td>9137.60</td><td>9154.50</td><td>3,984</td></tr><tr><td>48</td><td>9137.40</td><td>9154.60</td><td>763</td></tr><tr><td>144</td><td>9137.29</td><td>9154.71</td><td>157</td></tr><tr><td>136</td><td>9137.20</td><td>9154.80</td><td>56</td></tr><tr><td>528</td><td>9137.00</td><td>9155.50</td><td>320</td></tr><tr><td>1,654</td><td>9136.90</td><td>9155.71</td><td>200</td></tr><tr><td>40</td><td>9136.79</td><td>9156.10</td><td>16</td></tr><tr><td>46</td><td>9136.70</td><td>9156.21</td><td>219</td></tr><tr><td>608</td><td>9136.60</td><td>9156.30</td><td>40</td></tr><tr><td>48</td><td>9136.50</td><td>9156.40</td><td>80</td></tr></table>

# Cumulative Order Book

• For each of the bid and ask book, order size accumulates from the top of the book.

![](images/141e8b6f16ee4724150911c20de32c9481e617b6a0ffd9f405342bd4c77f037d.jpg)

<table><tr><td colspan="3">Order Book Market Trades</td></tr><tr><td>= = =</td><td rowspan="2">Qty(BTC)</td><td>0.1▼</td></tr><tr><td>Price(USDT)</td><td>Total(BTC)</td></tr><tr><td>61,284.8</td><td>11.972</td><td>54.521</td></tr><tr><td>61,284.7</td><td>7.282</td><td>42.549</td></tr><tr><td>61,284.0</td><td>2.529</td><td>35.267</td></tr><tr><td>61,283.9</td><td>1.305</td><td>32.738</td></tr><tr><td>61,283.8</td><td>1.795</td><td>31.433</td></tr><tr><td>61,283.7</td><td>4.569</td><td>29.638</td></tr><tr><td>61,283.5</td><td>5.773</td><td>25.069</td></tr><tr><td>61,283.4</td><td>1.795</td><td>19.296</td></tr><tr><td>61,283.3</td><td>3.590</td><td>17.501</td></tr><tr><td>61,283.2</td><td>13.911</td><td>13.911</td></tr><tr><td colspan="3">61,284.4 ↑ 61,291.9</td></tr><tr><td>61,282.3</td><td>12.075</td><td>12.075</td></tr><tr><td>61,282.2</td><td>0.816</td><td>12.891</td></tr><tr><td>61,282.1</td><td>2.693</td><td>15.584</td></tr><tr><td>61,282.0</td><td>4.712</td><td>20.296</td></tr><tr><td>61,281.9</td><td>9.444</td><td>29.740</td></tr><tr><td>61,281.8</td><td>1.795</td><td>31.535</td></tr><tr><td>61,281.7</td><td>3.672</td><td>35.207</td></tr><tr><td>61,281.6</td><td>5.181</td><td>40.388</td></tr><tr><td>61,278.4</td><td>15.301</td><td>55.689</td></tr><tr><td>61,267.2</td><td>15.306</td><td>70.995</td></tr></table>

My Portfolio

News

Markets

Sectors

Screeners

Personal Finance

Videos

# Summary

News

Chart

Conversations

Statistics

Historical Data

Profile

Financials

Analysis

Options

Holders

Sustainability

NasdaqGS - Nasdaq Real Time Price • USD

# Apple Inc. (AAPL)

Follow

$\rightarrow^{\dagger}$ Compare

# 207.49 -2.19 (-1.04%)

# 207.86 +0.37 (+0.18%)

At close: June 21 at 4:00 PM EDT

Pre-Market: 7:41 AM EDT

# Start Trading >>

Plus500 CFD Service. Your capital is at risk.

![](images/a92594ce88f7057bc67eae0caa630c03cf3bef9d391f01b0f85c9cfac59212dc.jpg)

<table><tr><td>Previous Close</td><td>209.68</td><td>Day&#x27;s Range</td><td>207.11 - 211.89</td><td>Market Cap (intraday)</td><td>3.182T</td><td colspan="2">Earnings Date Aug 1, 2024 - Aug 5, 2024</td></tr><tr><td>Open</td><td>210.39</td><td>52 Week Range</td><td>164.08 - 220.20</td><td>Beta (5Y Monthly)</td><td>1.25</td><td>Forward Dividend &amp; Yield</td><td>1.00 (0.48%)</td></tr><tr><td>Bid</td><td>207.01 x 3000</td><td>Volume</td><td>246,421,353</td><td>PE Ratio (TTM)</td><td>32.22</td><td>Ex-Dividend Date</td><td>May 10, 2024</td></tr><tr><td>Ask</td><td>209.94 x 200</td><td>Avg. Volume</td><td>67,794,775</td><td>EPS (TTM)</td><td>6.44</td><td>1y Target Est</td><td>207.58</td></tr></table>

# Bid Price & Bid Size

- Bid price is the highest price that a buyer (bidder) is willing to pay for a particular security.   
- Bid size represents the quantity a buyer is willing to purchase at the bid price.   
- The top price and size in a bid order book.   
• For example, if a buyer bids $207.01 x 3000 for a stock, it means they are willing to buy 3000 shares for not more than$ 207.01

# Ask Price & Ask Size

- Ask price is the lowest price a seller is willing to accept for a security.   
- Ask size represents the quantity a seller is willing to sell at the ask price.   
- The top price and size in an ask order book.   
• For example, if a seller asks $209.94 \times 200 for a stock, it implies they are willing to sell 200 shares for not less than$ 209.94

# HKEX Market Data Pricing

- Level 1 data:   
• bid/ask price: HK$500 /month   
- Level 2 data:   
- full order book: HK$5,000 /month

# HKEX

香港交易所

Historical Full Book - Securities Market (Binary Format) provides information on every order and trade of Main Board and GEM stocks in binary format. File is available on a daily basis, normally at around 8:30pm.   
Historical Full Book - Securities Market (CSV Format) provides information on every order and trade of Main Board and GEM stocks in CSV format. File is available on a daily basis, normally at around 10:00pm.   
Historical Order Book and Statistics Update - Securities Market provides intra-day order book and statistics information recorded on the HKEX's Main Board and GEM stocks in CSV format. File is available on a daily basis, normally at around 10:00pm.   
Bid and Ask Record - Main Board & GEM (Daily File) provides intra-day bid and ask information on Main Board and GEM stocks   
Bid and Ask Record - Main Board & GEM (Monthly File) provides intra-day bid and ask information on Main Board and GEM stocks   
Trade File - Securities Market (Binary Format) provides trade details, including trade time, price and quantity, of each transaction recorded on the Main Board and GEM in binary format. File is available on a daily basis, normally at around 8:30pm.   
Trade File - Securities Market (CSV) provides trade details, including trade time, price and quantity, of each transaction recorded on the Main Board and GEM in CSV format. File is available on a daily basis, normally at around 10:00pm.

![](images/a7956b2d8383c6a5aabd5022a273670e5bfa747de9a83241a184467998961936.jpg)

![](images/98ea7b18fef22b54f82498e9bb784fd403ed28bf2148ee0d1032cb3dcb7a6685.jpg)

$5,000/ Month

![](images/2ff2039e4730d63ff93056983d7837af278741d2cfba027fdfefaa102473b376.jpg)

$5,000/ Month

![](images/d74d447c92966acb21a5e9e319faf13eaa3bc6f054024cccea30129052bacebe.jpg)

$2,500/ Month

![](images/50018306927a07d1ff6b560ed36879285b09d927b0420483db02b9cff0bd5e2e.jpg)

$500/ Month

![](images/d240eec30502a7601eaf85da93182f883248a16e41530d00b09804f4265aa9d4.jpg)

$500/ Month

![](images/6878284176ca321419f78a4d6a00d0b54c72f835dc419e7490bb2b2d3915d6cc.jpg)

$2,500/ Month

![](images/07461bb1cf3e35252e64819e2ee160d6cd1b2f8ec310b750067381e98efc347d.jpg)

$2,500/ Month

# Market Spread

- The difference between the bid price and the ask price is known as the bid-ask spread.   
- The bid-ask spread is a key measure of the liquidity of an asset or security.   
- A smaller spread indicates a more liquid market, while a larger spread indicates a less liquid market.   
• For example, if the bid price for a stock is $24 and the ask price is $25, the bid-ask spread will be $1.

# Percentage Spread

- Percentage spread is often used for comparing the spread between different instruments

$$
\text{Percentage Spread} = \frac {\text {AskPrice} - \text {BidPrice}}{\text {MidPrice}} \times 100 \% = \frac {2 \times (\text {AskPrice} - \text {BidPrice})}{\text {AskPrice} + \text {BidPrice}} \times 100 \%
$$

• For example, if the bid price for a stock is $24 and the ask price is $25,

• the bid-ask spread will be (25-24) = $1   
- the percentage spread will be $2^{*}(25 - 20) / (25 + 20) = 4.08\%$

# Order Types

1. Market Order   
2. Limit Order   
3. Stop Order

![](images/1251d110ed9aaf8c1d6abc145dad130065bd8502f6bfe2e42e0b37e9673560fe.jpg)

# Market Order

- A market order is to buy or sell at the best available price in the current market.   
- That is, when opening a buy (sell) position using market order, it will try to execute at the best ask (bid) price.   
- A market order typically ensures an execution, but it does not guarantee a specified price. It is appropriate to use market orders when you want an immediate execution.

![](images/8c694ecb9c3bbd40d28b4c509ad59d0300e050c68909faaa8e81981cacd4710d.jpg)

# Limit Order

- A limit order is to buy or sell with a condition on the maximum price to pay or the minimum price to receive (the "limit price").   
- If the order is filled, it will only be at the specified limit price or better. However, there is no guarantee of execution.   
- A limit order may be appropriate when you think you can buy at a price lower than (or sell at a price higher than) the current market quote.

# Limit Order Example

![](images/b8adfb1eb68635e77d4d516ecfe0712fe1c40c9ae25ad17a09f5a1a6aa25f67c.jpg)

# Limit Order Example

# - The last trade price is roughly $138

investor who wants to buy (or sell) immediately would place a market order, which would be executed at or near the current price of \(138 (white line) provided that the market was open.   
investor who wants to buy the stock when it dropped to \(131.78 would place a buy limit order with a limit price of\)131.78 (green line). If the price falls to \(131.78 or lower, the limit order would be triggered and executed at \)131.78 or below. If the stock doesn't drop to \(131.78 or below, no execution would occur.   
investor who wants to sell the stock when it reached \(143.82 would place a sell limit order with a limit price of\)143.82 (red line). If the price rises to \(143.82 or higher, the limit order would be triggered and executed at \)143.82 or above. If the stock doesn't rise to \(143.82 or above, no execution would occur.

# Stop Order

- A stop order is to buy or sell at the market price when it has traded at or through a specified price (the "stop price").   
- If the stock reaches the stop price, the order becomes a market order and is filled at the next available market price. If it doesn't reach the stop price, the order will not be executed.   
- A stop order may be appropriate in these scenarios:

- you want to buy when a stock breaks out above a certain level, and believe that it will continue the trend   
- your holding stock has risen a lot and you want to protect the gain when it begins to fall

# Stop Order Example

![](images/e61f773bf848a8135ad8fef549b38f64214548d74db1fb87fb3099726cd18372.jpg)

# Stop Order Example

- The stop buy order will trigger when the price reaches 143.82 or above, and will execute as a market order at that current price.   
- Thus, if the price rise further after hitting the stop price, it is possible that the order could be executed at a price higher than the stop price.   
- Similarly for the stop sell order, once the stop price of $131.78 is reached, the order could be executed at a lower price

# Slippage

- Slippage refers to the difference between the expected execution price and the price it actually traded   
- It often occurs

- during periods of higher volatility when market orders are used   
- when large orders are executed when market depth is not sufficient to maintain the expected price of trade

# Slippage Example

- Let's assume you have an algorithm set to buy a stock when the price drops to $50. The algorithm detects the price drop and places a buy order.   
However, due to high demand or low liquidity, the order gets executed at $51. This$ 1 difference is the slippage.   
• This means that even if you were expecting to spend $5000 on 100 shares, you would end up spending $5100. The $100 is the cost of slippage

# Profit/Loss Calculation

- Entry: Based on a trade signal, generate order to go short or long a certain financial instrument in a certain quantity. Trade results in a certain position in this security   
- Mark-to-Market: As the price of the security changes, so does your unrealized PnL

$$
F o r l o n g o r d e r, P n L = Q u a n t i t y * (P _ {b i d} - P _ {e n t r y})
$$

$$
F o r s h o r t o r d e r, P n L = - 1 * Q u a n t i t y * (P _ {a s k} - P _ {e n t r y})
$$

- Exit: Generate order to exit the position and create a realized PnL

$$
\mathrm {P n L} = \mathrm {S i d e} * \mathrm {Q u a n t i t y} * \left(P _ {\mathrm {e x i t}} - P _ {\mathrm {e n t r y}}\right)
$$

# Mark-to-Market

- It is an accounting method to calculate the asset or portfolio value according to its current market value, rather than its book value   
- It involves determining the price at which you could immediately sell an asset or close a position   
• Example:

- Suppose you purchase 100 shares of ABC stock   
- The current bid and ask price of ABC are $9.5 and$ 10.5   
• Mark-to-market value of your stock will be $100 *$ 9.5 = $9500

# Order Management System (OMS)

# 1. Order based system

- Transactions are managed in a round order manner   
- Partial close is not supported   
- Trading platforms

MetaTrader, TradingView, MetaStock, etc

# 2. Position based system

- Transactions are independent and no linkage with each other   
- Partial close is allowed   
- Trading Platforms

- Most of the banks (eg. HSBC, SBC, BOC, etc)   
- Interactive Brokers, Binance, etc

# Position Based vs Order Based System

Suppose you open 3 offsetting trades:

#1: buy 2 shares of ABC at $123   
#2: sell 1 share of ABC at $124   
#3: sell 1 share of ABC at $125

For order based system, the unrealized PnL will be \(2^{*}(\mathrm{bid} - 123) + 1^{*}(124 - \mathrm{ask}) +\) \(1^{*}(125 - \mathrm{ask}) = \\(3 + 2^{*}(\mathrm{bid} - \mathrm{ask})\). You need to close all the 3 trades to realize the PnL.

For position based system, the orders will be offsetted based on FIFO, and PL will become realized so long as the position is net to zero. Thus, your PnL will be realized at $3.

# Leverage & Margin

# Leverage & Margin

- Leverage refers to using borrowed capital as a funding source for investment to increase the potential return

$$
\text {L e v e r a g e R a t i o} = \text {A s s e t / E q u i t y} = 1 + \text {D e b t / E q u i t y}
$$

- Margin is a way to create leverage

Margin Amount = (Account Asset Value) - (Borrowed Amount) = Equity held at broker

# Margin Requirement

# There are 2 market quotations for margin requirement

1. Fixed Margin Amount: Mostly used by stock exchanges   
2. Margin as a percentage: Mostly used by FX/Crypto exchanges

Update Date: 20251006

Please be reminded that the minimum margin rates below are for your firm's financially strongest client.

Exchange Participants should set their margin requirements according to each client's individual circumstances.

Index Futures

<table><tr><td rowspan="2">Effective Date</td><td rowspan="2">Product</td><td rowspan="2" colspan="2">HKATS
Code</td><td colspan="2">Client Margin</td><td>Clearing House
Margin</td></tr><tr><td>Initial
(HK$)</td><td>Maintenance
(HK$)</td><td>(HK$)</td></tr><tr><td rowspan="2">20251002</td><td rowspan="2">Hang Seng Index</td><td rowspan="2">HSI</td><td>Full Rate
/lot</td><td>116,774</td><td>93,419</td><td>87,800</td></tr><tr><td>Spread Rate
/spread</td><td>25,735</td><td>20,588</td><td>19,350</td></tr><tr><td rowspan="2">20251002</td><td rowspan="2">Mini-Hang Seng Index</td><td rowspan="2">MHI</td><td>Full Rate
/lot</td><td>23,354</td><td>18,683</td><td>17,560</td></tr><tr><td>Spread Rate
/spread</td><td>5,147</td><td>4,117</td><td>3,870</td></tr></table>

# How Margin is related to Leverage?

• As HSI Index Future has a price magnifier of 50, meaning that 1 index point change will lead to ±HK$50. Suppose current HSI Index Future price is 25000, and buying 1 lot of HSI Index Future require HK$116,774 as margin. Then, leverage ratio is calculated to be ($25000*50)/$116,774 = 10.7044   
• Suppose you pay $600,000 to get stocks worth $1,000,000. Thus, leverage ratio is calculated to be $1,000,000/$600,000 = 1.6667   
- As you can imagine, the lower is the margin requirement, the higher is the leverage ratio. In general,

$$
L e v e r a g e \mathrm {R a t i o} = \frac {1}{\text {M a r g i n R e q u i r e m e n t}}
$$

# Buying Power

- For leveraged trading where traders can take out a loan based on the amount of cash held in their broker account, buying power refers to the amount of money available for investors to purchase securities. Mathematically,

$$
B u y i n g P o w e r = (L e v e r a g e R a t i o) \times (I n v e s t o r ^ {\prime} s e q u i t y)
$$

- For example, suppose an investor made an initial deposit US $100,000 to a 20:1 leveraged broker account. Then, the investor would be able to purchase, at maximum, US$ 2,000,000 worth of securities. Hence, a buying power of US$2,000,000

# Key Takeaways

- Learn the basic concept of algo-trading and its market trend   
- Understand the pros and cons of different trading approaches   
- Know about the infrastructure/resources needed to develop and deploy algo-trading programs in real market   
- Understand the trading mechanism and order matching in financial market   
- Equip the knowledge about different market terminology (eg. Order book, order types, market spread, slippage, order/position based trading system, margin, etc)